# Teacher Info Block for Moodle 5

This block displays the course teacher's information, including their profile picture, name, and quick links to their CV, calendar, and email.

## Installation

1. Upload the `teacher_info.zip` via Moodle’s plugin installer.
2. Follow the on-screen instructions to complete installation.
3. Add the block to a course page from the "Add a block" menu.

Enjoy!
