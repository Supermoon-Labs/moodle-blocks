<?php
$string['pluginname'] = 'Mi tutor';
$string['cv'] = 'CV';
$string['downloadcv'] = 'Descargar CV';
$string['uploadcv'] = 'Subir CV';
$string['email'] = 'Email';
$string['noteacherfound'] = 'No se ha encontrado tutor para este curso.';
